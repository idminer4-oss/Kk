
import React, { useState } from 'react';
import { Pickaxe, Mail, Phone, Lock, ChevronRight, Eye, EyeOff } from 'lucide-react';
import { User } from '../types';

interface AuthProps {
  onLogin: (user: User) => void;
}

const Auth: React.FC<AuthProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isRegister, setIsRegister] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && phone && password) {
      if (password.length < 6) {
        alert("Password must be at least 6 characters");
        return;
      }

      // Check if this is the first user ever registered in this browser
      const existingUsers = localStorage.getItem('minier_all_users');
      const usersList = existingUsers ? JSON.parse(existingUsers) : [];
      
      const isFirstUser = usersList.length === 0;
      const newUser: User = {
        email,
        phone,
        isLoggedIn: true,
        role: isFirstUser ? 'admin' : 'user'
      };

      // Save to "database"
      usersList.push({ email, phone, role: newUser.role });
      localStorage.setItem('minier_all_users', JSON.stringify(usersList));

      onLogin(newUser);
    }
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-[#0a0a0c] flex flex-col p-8 items-center justify-center relative overflow-hidden">
      {/* Background Animated Elements */}
      <div className="absolute top-[-100px] right-[-100px] w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-[-100px] left-[-100px] w-64 h-64 bg-blue-500/10 rounded-full blur-3xl"></div>

      <div className="z-10 w-full">
        <div className="flex flex-col items-center mb-12 animate-float">
          <div className="bg-gradient-to-br from-yellow-400 to-yellow-600 p-5 rounded-3xl shadow-[0_10px_40px_rgba(234,179,8,0.4)] mb-4">
            <Pickaxe className="w-12 h-12 text-black" />
          </div>
          <h1 className="font-orbitron text-2xl font-bold text-white tracking-tighter">COIN IDR <span className="text-yellow-500">MINIER</span></h1>
          <p className="text-gray-500 text-sm mt-2">Next Gen Cloud Mining Platform</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">Phone Number</label>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="tel" 
                placeholder="0831XXXXXX"
                required
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500/50 transition-all"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="email" 
                placeholder="user@example.com"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500/50 transition-all"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-gray-500 uppercase ml-1">Account Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type={showPassword ? "text" : "password"} 
                placeholder="••••••••"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-12 text-white focus:outline-none focus:ring-2 focus:ring-yellow-500/50 transition-all"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-yellow-500 text-black font-bold py-4 rounded-2xl shadow-lg hover:bg-yellow-400 active:scale-95 transition-all flex items-center justify-center gap-2 mt-6"
          >
            {isRegister ? 'Create Account' : 'Start Mining'}
            <ChevronRight className="w-5 h-5" />
          </button>
        </form>

        <p className="text-center text-gray-500 mt-8 text-sm">
          {isRegister ? 'Already have an account?' : 'Don\'t have an account?'}
          <button 
            onClick={() => setIsRegister(!isRegister)}
            className="text-yellow-500 font-bold ml-2 underline underline-offset-4"
          >
            {isRegister ? 'Sign In' : 'Join Now'}
          </button>
        </p>
      </div>

      <div className="mt-12 text-center opacity-40">
        <p className="text-[10px] text-gray-400 uppercase tracking-widest">Powered by Gemini AI Network</p>
      </div>
    </div>
  );
};

export default Auth;
